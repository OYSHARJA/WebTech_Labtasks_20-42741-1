<!DOCTYPE html>
<html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body{ font: 14px sans-serif; }
        .wrapper{ width: 360px; padding: 20px; }
        footer {
  background-color: transparent;
  margin-top: -0.5em;
  padding: 2em;
  position: fixed; 
  left: 50%;
  transform:translateX(-50%);
  bottom: -3em;

}
    </style>
</head>
<body>

<footer>
  <div class="header-left">
  <h5 style="text-align:left">© Copyright</h5>
    <p> Wed-site Event Management 2022</p>
  </div>
</footer>


</body>
</html>
