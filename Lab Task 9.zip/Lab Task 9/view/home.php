<?php
include ("../view/header.php");
?>
<!DOCTYPE html>
<html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body{ font: 14px sans-serif;
        background-image: url('../assets/background.jpg'); }
        .wrapper{ width: 360px; padding: 20px; }
    </style>
</head>
    <body> 
    <div style="padding-left:20px">
    <h1>Welcome</h1><br>
    <h2>to Wed-site</h2><br>
    <h3>Event Management Page</h3><br>
    </div>
    </body>
</html>

<?php
include ("footer.php");
?>
