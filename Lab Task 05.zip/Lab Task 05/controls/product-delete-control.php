<?php 
    session_start();
    require("../models/data-model.php");

    $_SESSION["pd_msg"] = "";

    if(isset($_POST["delete"])){
        deleteProduct($_POST["serial"]);
        $_SESSION["pd_msg"] = " product is deleted ";
    }else{
        $_SESSION["pd_msg"] = " Id is not selected ";
    }
    header("location: ../views/list-product-view.php");


?>