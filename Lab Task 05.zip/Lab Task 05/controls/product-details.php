<?php 
require("../models/data-model.php");

function get_a_product($id){
    return showProduct($id);
}

?>