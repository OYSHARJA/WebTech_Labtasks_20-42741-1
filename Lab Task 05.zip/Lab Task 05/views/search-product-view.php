<?php 
session_start();
require("../controls/list-product-control.php");
?>
<h1 style="color:blue">Search Product</h1><br>
<table border="1">
<thead>
    <tr>
        <th>Product No</th>
        <th>Name</th>
        <th>Buying Price</th>
        <th>Selling Price</th>
        <th colspan="2">Action</th>
    </tr>
</thead>
<tbody>
    <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post">
        <input type="text" name="nm" placeholder="Search by product name">
        <input type="submit" value="Search By Name" name="search">
    </form>
    
    <?php 
    $name = "";
    if(isset($_POST["search"])){
        $name = $_POST["nm"];
    }
    $rows = get_data_by_name($name);
    foreach($rows as $i => $row){ 
    ?>
    <tr>
        <td><?php echo $row["SL"]; ?></td>
        <td><?php echo $row["Name"]; ?></td>
        <td><?php echo $row["buying_price"]; ?></td>
        <td><?php echo $row["selling_price"]; ?></td>
        <td><a href="../views/delete-product-view.php?id=<?php echo $row["SL"]; ?>">Delete</a></td>
        <td><a href="../views/update-product-view.php?id=<?php echo $row["SL"]; ?>">Edit</a></td>
    </tr>
    <?php } ?>
</tbody>
</table>
<p><?php 
    if(isset($_SESSION["pd_msg"])){
        echo $_SESSION["pd_msg"];
        $_SESSION["pd_msg"] = "";
    }
?></p>
<a href="../index.php">Home Page</a>